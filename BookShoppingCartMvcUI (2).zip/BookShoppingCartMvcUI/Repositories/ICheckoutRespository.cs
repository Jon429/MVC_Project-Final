﻿namespace BookShoppingCartMvcUI.Repositories
{
    public class ICheckoutRespository
    {
    }
}
